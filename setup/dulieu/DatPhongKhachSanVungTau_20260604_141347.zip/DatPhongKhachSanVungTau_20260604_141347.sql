﻿CREATE TABLE [KhachSan] (
    [MaKhachSan] int NOT NULL IDENTITY,
    [TenKhachSan] nvarchar(150) NOT NULL,
    [KhuVuc] nvarchar(50) NOT NULL,
    [DiaChiChiTiet] nvarchar(255) NOT NULL,
    [MoTa] nvarchar(max) NULL,
    [HinhAnh] nvarchar(500) NULL,
    [XepHang] int NOT NULL,
    [KhoangCachBien] int NOT NULL,
    CONSTRAINT [PK_KhachSan] PRIMARY KEY ([MaKhachSan])
);
GO


CREATE TABLE [LoaiPhong] (
    [MaLoaiPhong] int NOT NULL IDENTITY,
    [TenLoaiPhong] nvarchar(80) NOT NULL,
    [SoNguoiToiDa] int NOT NULL,
    [MoTa] nvarchar(max) NULL,
    CONSTRAINT [PK_LoaiPhong] PRIMARY KEY ([MaLoaiPhong])
);
GO


CREATE TABLE [NguoiDung] (
    [MaNguoiDung] int NOT NULL IDENTITY,
    [TenDangNhap] nvarchar(50) NOT NULL,
    [MatKhau] nvarchar(255) NOT NULL,
    [HoTen] nvarchar(100) NOT NULL,
    [Email] nvarchar(100) NOT NULL,
    [SoDienThoai] nvarchar(15) NULL,
    [CCCD] nvarchar(12) NULL,
    [DiaChi] nvarchar(255) NULL,
    [VaiTro] nvarchar(20) NOT NULL DEFAULT N'KhachHang',
    [TrangThaiTaiKhoan] nvarchar(20) NOT NULL DEFAULT N'HoatDong',
    CONSTRAINT [PK_NguoiDung] PRIMARY KEY ([MaNguoiDung])
);
GO


CREATE TABLE [Phong] (
    [MaPhong] int NOT NULL IDENTITY,
    [SoPhong] nvarchar(20) NOT NULL,
    [MaKhachSan] int NOT NULL,
    [MaLoaiPhong] int NOT NULL,
    [GiaMotDem] decimal(18,0) NOT NULL,
    [HuongPhong] nvarchar(50) NOT NULL,
    [MoTa] nvarchar(max) NULL,
    [HinhAnh] nvarchar(500) NULL,
    [TienNghi] nvarchar(max) NULL,
    [TrangThai] nvarchar(30) NOT NULL DEFAULT N'Còn trống',
    CONSTRAINT [PK_Phong] PRIMARY KEY ([MaPhong]),
    CONSTRAINT [FK_Phong_KhachSan_MaKhachSan] FOREIGN KEY ([MaKhachSan]) REFERENCES [KhachSan] ([MaKhachSan]) ON DELETE NO ACTION,
    CONSTRAINT [FK_Phong_LoaiPhong_MaLoaiPhong] FOREIGN KEY ([MaLoaiPhong]) REFERENCES [LoaiPhong] ([MaLoaiPhong]) ON DELETE NO ACTION
);
GO


CREATE TABLE [DatPhong] (
    [MaDatPhong] int NOT NULL IDENTITY,
    [MaNguoiDung] int NOT NULL,
    [MaPhong] int NOT NULL,
    [NgayNhanPhong] datetime2 NOT NULL,
    [NgayTraPhong] datetime2 NOT NULL,
    [SoDem] int NOT NULL,
    [SoKhach] int NOT NULL,
    [TongTien] decimal(18,0) NOT NULL,
    [GhiChu] nvarchar(max) NULL,
    [PhuongThucThanhToan] nvarchar(30) NOT NULL,
    [TrangThai] nvarchar(30) NOT NULL,
    [NgayDat] datetime2 NOT NULL DEFAULT (GETDATE()),
    CONSTRAINT [PK_DatPhong] PRIMARY KEY ([MaDatPhong]),
    CONSTRAINT [FK_DatPhong_NguoiDung_MaNguoiDung] FOREIGN KEY ([MaNguoiDung]) REFERENCES [NguoiDung] ([MaNguoiDung]) ON DELETE NO ACTION,
    CONSTRAINT [FK_DatPhong_Phong_MaPhong] FOREIGN KEY ([MaPhong]) REFERENCES [Phong] ([MaPhong]) ON DELETE NO ACTION
);
GO


CREATE INDEX [IX_DatPhong_MaNguoiDung] ON [DatPhong] ([MaNguoiDung]);
GO


CREATE INDEX [IX_DatPhong_MaPhong_NgayNhanPhong_NgayTraPhong] ON [DatPhong] ([MaPhong], [NgayNhanPhong], [NgayTraPhong]);
GO


CREATE INDEX [IX_DatPhong_TrangThai] ON [DatPhong] ([TrangThai]);
GO


CREATE INDEX [IX_KhachSan_KhuVuc] ON [KhachSan] ([KhuVuc]);
GO


CREATE INDEX [IX_LoaiPhong_TenLoaiPhong] ON [LoaiPhong] ([TenLoaiPhong]);
GO


CREATE UNIQUE INDEX [IX_NguoiDung_Email] ON [NguoiDung] ([Email]);
GO


CREATE UNIQUE INDEX [IX_NguoiDung_TenDangNhap] ON [NguoiDung] ([TenDangNhap]);
GO


CREATE UNIQUE INDEX [IX_Phong_MaKhachSan_SoPhong] ON [Phong] ([MaKhachSan], [SoPhong]);
GO


CREATE INDEX [IX_Phong_MaLoaiPhong] ON [Phong] ([MaLoaiPhong]);
GO


